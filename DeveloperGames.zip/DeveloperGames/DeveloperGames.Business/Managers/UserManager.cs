﻿using DeveloperGames.Core.Interfaces;
using DeveloperGames.Core.Interfaces.Repositories;
using DeveloperGames.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DeveloperGames.Core.Models;
using DeveloperGames.Core.ViewModels;
using DeveloperGames.Core.Enums;

namespace DeveloperGames.Business.Managers
{
    public class UserManager : IUserManager
    {
        private IUserRepository userRepository;
        public UserManager(IUserRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        public int SetPassword(int userId, string password)
        {
            return this.userRepository.SetPassword(userId,password);
        }
        public int setUserInfo(User userinfo)
        {
          return this.userRepository.SetUser(userinfo);
        }
        public User getUserInfobyUserName(string username)
        {
            return this.userRepository.GetUserByUserName(username);
        }

        public int SetCharacter(CharacterEntity charc)
        {
            return this.userRepository.SetCharacter(charc);
        }

        public List<CharacterEntity> GetCharacters(int userId,int characterId)
        {
            return this.userRepository.GetCharacters(userId, characterId).ToList();
        }

        public int SetLoginAttemptsByUserId(int userId,bool reset)
        {
            return this.userRepository.SetLoginAttemptsByUserId(userId,reset);
        }
    }
}
