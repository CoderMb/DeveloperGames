﻿using DeveloperGames.Core.Interfaces;
using DeveloperGames.Core.Interfaces.Repositories;
using DeveloperGames.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperGames.Business.Managers
{
    public class AdminManager : IAdminManager
    {
        private IAdminRepository adminRepo;
        private IUserRepository userRepository;
        public AdminManager(IAdminRepository adminRepo, IUserRepository userRepository)
        {
            this.adminRepo = adminRepo;
            this.userRepository = userRepository;
        }

        public List<User> GetUsers()
        {
            return this.userRepository.GetUsers();
        }
        public List<ClassEntity> GetAllClasses()
        {
            return adminRepo.GetAllClasses();
        }

        public int SetClass(ClassEntity classList)
        {
            return adminRepo.SetClass(classList);
        }

        public List<GlobalSettings> GetGlobalSettings()
        {
            return adminRepo.GetGlobalSettings();
        }

        public int SetCharacterSetting(int id, int capacity)
        {
            return adminRepo.SetCharacterSetting(id, capacity);
        }
    }
}
