﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperGames.Utilities
{
    public static class Hash
    {


        private const int keysize = 256;

        public static string generteHashPassword(string plainText)
        {
            string passPhrase = "9af25034-2188-4605-9db0-becfedc5a85c";
            byte[] cipherTextBytes = null;

            if (!String.IsNullOrEmpty(plainText) && !String.IsNullOrEmpty(passPhrase))
            {
                byte[] initVectorBytes = Encoding.UTF8.GetBytes(ConfigurationManager.AppSettings["EncyrptPassKey"]);
                byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
                PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
                byte[] keyBytes = password.GetBytes(keysize / 8);
                using (RijndaelManaged symetricKey = new RijndaelManaged())
                {
                    symetricKey.Mode = CipherMode.CBC;
                    using (ICryptoTransform encryptor = symetricKey.CreateEncryptor(keyBytes, initVectorBytes))
                    {
                        using (MemoryStream memoryStream = new MemoryStream())
                        {
                            using (CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                            {
                                cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
                                cryptoStream.FlushFinalBlock();
                                cipherTextBytes = memoryStream.ToArray();
                                //memoryStream.Close();
                                //cryptoStream.Close();
                            }
                        }
                    }
                }

            }

            return Convert.ToBase64String(cipherTextBytes);

        }

        public static byte[] GetEncrypted(string plainText, byte[] key, byte[] iv)
        {
            try
            {
                byte[] encrypted = null;
                if (plainText != null && plainText.Length > 0)
                {
                    using (RijndaelManaged rijAlg = new RijndaelManaged())
                    {
                        rijAlg.Key = key;
                        rijAlg.IV = iv;
                        ICryptoTransform encryptor = rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV);
                        using (MemoryStream msEncrypt = new MemoryStream())
                        {
                            using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                            {
                                using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                                {
                                    swEncrypt.Write(plainText);
                                }
                                encrypted = msEncrypt.ToArray();
                            }
                        }
                    }
                }
                return encrypted;
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public static string EncryptParameters(string plainText)
        {
            try
            {
                byte[] key = Convert.FromBase64String(ConfigurationManager.AppSettings["EncyrptParamKey"]);
                byte[] iv = Convert.FromBase64String(ConfigurationManager.AppSettings["DecyrptParamIV"]);
                return Convert.ToBase64String(GetEncrypted(plainText, key, iv));
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public static string DecryptParameters(string cipherString)
        {
            string plaintext = null;
            byte[] cipherText = Convert.FromBase64String(cipherString);
            if (cipherText != null && cipherText.Length > 0)
            {
                using (RijndaelManaged rijAlg = new RijndaelManaged())
                {
                    rijAlg.Key = Convert.FromBase64String(ConfigurationManager.AppSettings["EncyrptParamKey"]);
                    rijAlg.IV = Convert.FromBase64String(ConfigurationManager.AppSettings["DecyrptParamIV"]);
                    ICryptoTransform decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);
                    using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                    {
                        using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                            {
                                plaintext = srDecrypt.ReadToEnd();
                            }
                        }
                    }
                }
            }
            return plaintext;
        }
    }
}
