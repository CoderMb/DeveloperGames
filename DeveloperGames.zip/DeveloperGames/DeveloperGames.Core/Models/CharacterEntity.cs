﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperGames.Core.Models
{
    public class CharacterEntity
    {
        public int CharacterId { get; set; }
        [StringLength(250)]
        public string CharacterName { get; set; }
        public int ClassId { get; set; }
        public string CharacterImage { get; set; }
        [StringLength(10)]
        public string Gender { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }

    }
}
