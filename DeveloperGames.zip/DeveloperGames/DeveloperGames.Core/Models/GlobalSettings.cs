﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperGames.Core.Models
{
    public class GlobalSettings
    {
        public int GlobalSettingKeyId { get; set; }
        public string GlobalSettingKeyName { get; set; }
        public int GlobalSettingKeyValue { get; set; }
    }
}
