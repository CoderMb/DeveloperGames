﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperGames.Core.Models
{
    public class ClassEntity
    {
        public int ClassID { get; set; }
        public string ClassName { get; set; }
        public string ClassDescription {get;set;}
        public string ClassImageURL { get; set; }
        public int GlobalSettingsKeyId { get; set; }
    }
}
