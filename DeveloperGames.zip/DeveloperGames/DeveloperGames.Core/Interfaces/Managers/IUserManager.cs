﻿using DeveloperGames.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DeveloperGames.Core.Models;
using DeveloperGames.Core.ViewModels;
namespace DeveloperGames.Core.Interfaces
{
    public interface IUserManager
    {
        int setUserInfo(User userinfo);
        int SetCharacter(CharacterEntity charc);
        int SetLoginAttemptsByUserId(int userId,bool reset);
        List<CharacterEntity> GetCharacters(int userId, int characterId);
        User getUserInfobyUserName(string username);

        int SetPassword(int userId, string password);

    }
}
