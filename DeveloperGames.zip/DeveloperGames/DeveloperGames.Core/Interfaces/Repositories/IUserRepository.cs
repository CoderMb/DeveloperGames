﻿using DeveloperGames.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperGames.Core.Interfaces.Repositories
{
   public interface IUserRepository

    {
        List<User> GetUsers();

        User GetUserById(int userId);
        int SetUser(User user);
        User GetUserByUserName(string username);
        int SetLoginAttemptsByUserId(int userId, bool reset);
        IEnumerable<CharacterEntity> GetCharacters(int userId, int characterId);
        int SetCharacter(CharacterEntity charc);
        int SetPassword(int userId, string password);

    }
}
