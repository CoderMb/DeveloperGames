﻿using DeveloperGames.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperGames.Core.Interfaces.Repositories
{
    public interface IAdminRepository
    {
        List<ClassEntity> GetAllClasses();
        int SetClass(ClassEntity classList);
        List<GlobalSettings> GetGlobalSettings();
        int SetCharacterSetting(int id, int capacity);
    }
}
