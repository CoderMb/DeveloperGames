﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperGames.Core.ViewModels
{
    public class ChangePasswordViewModel
    {
        [Required(ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_Password_Required")]
        [StringLength(maximumLength: 15, MinimumLength = 8, ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_Password_Length")]
        [RegularExpression(@"(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?!.*\s).*$", ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_Password_Invalid")]
        public string NewPassword { get; set; }
        [Required(ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_ConfirmPassword_Required")]
        [StringLength(maximumLength: 15, MinimumLength = 8, ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_ConfirmPassword_Length")]
        //[RegularExpression(@"(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?!.*\s).*$", ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_ConfirmPassword_Invalid")]
        [RegularExpression(@"(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?!.*\s).*$", ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_ConfirmPassword_Invalid")]
        [Compare("NewPassword", ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_ConfirmPassword_Match")]
        public string ConfirmNewPassword { get; set; }
    }
}
