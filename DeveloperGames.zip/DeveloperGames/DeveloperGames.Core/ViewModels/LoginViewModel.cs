﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperGames.Core.ViewModels
{
   public class LoginViewModel
    {
        [Required(ErrorMessageResourceType =typeof(DeveloperGames.Core.Resources.DeveloperGameMessages),ErrorMessageResourceName = "Login_UserName_Required")]
        public string UserName { get; set; }
        [Required(ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Login_Password_Required")]
        [RegularExpression(@"(?=^.{8,15}$)(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?!.*\s).*$", ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Login_Password_Invalid")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
