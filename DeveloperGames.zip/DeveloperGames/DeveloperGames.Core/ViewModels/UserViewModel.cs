﻿using DeveloperGames.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperGames.Core.ViewModels
{
   public class UserViewModel
    {
        public List<User> Users { get; set; }
        public CharacterEntity Character { get; set; }
        public int CharacterId { get; set; }
        public List<ClassEntity> Classes { get; set; }
        public Setting CharacterSetting { get; set; }
        public List<CharacterEntity> Characters { get; set; }
        public bool IsEdit { get; set; }
    }
}
