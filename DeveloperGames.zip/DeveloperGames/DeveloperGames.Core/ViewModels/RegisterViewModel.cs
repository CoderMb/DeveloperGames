﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperGames.Core.ViewModels
{
    public class RegisterViewModel
    {

        [Required(ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_UserName_Required")]
        [StringLength(maximumLength: 20, MinimumLength = 3, ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_UserName_Length")]
        [RegularExpression(@"^(?![_.])(?!.*[_.]{2})[a-zA-Z0-9._]+(?<![_.])(?!.*\s).*$", ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_UserName_Invalid")]
        public string UserName { get; set; }
        [Required(ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_Email_Required")]
        [StringLength(maximumLength: 64, ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_Email_Length")]
        [EmailAddress(ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_Email_Invalid")]
        public string Email { get; set; }
        [Required(ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_Password_Required")]
        [StringLength(maximumLength: 15,MinimumLength =8, ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_Password_Length")]
        [RegularExpression(@"(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?!.*\s).*$", ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_Password_Invalid")]
        public string Password { get; set; }
        [Required(ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_ConfirmPassword_Required")]
        [StringLength(maximumLength: 15, MinimumLength = 8, ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_ConfirmPassword_Length")]
        //[RegularExpression(@"(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?!.*\s).*$", ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_ConfirmPassword_Invalid")]
        [RegularExpression(@"(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?!.*\s).*$", ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_ConfirmPassword_Invalid")]
        [Compare("Password", ErrorMessageResourceType = typeof(DeveloperGames.Core.Resources.DeveloperGameMessages), ErrorMessageResourceName = "Register_ConfirmPassword_Match")]
        public string ConfirmPassword { get; set; }
    }
}
