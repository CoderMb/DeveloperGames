﻿using DeveloperGames.Business.Managers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using Unity;
using Unity.AspNet.Mvc;
using Unity.RegistrationByConvention;

//[assembly: WebActivatorEx.PreApplicationStartMethod(typeof(DeveloperGames.App_Start.UnityConfig), "Start")]
//[assembly: WebActivatorEx.ApplicationShutdownMethod(typeof(DeveloperGames.App_Start.UnityConfig), "Shutdown")]
namespace DeveloperGames.App_Start
{
    public class UnityConfig
    {
        private static  IUnityContainer container;

        private static IEnumerable<Type> GetTypes()
        {
            var types = AllClasses.FromLoadedAssemblies();
            var ts = types.Where(a => (a.FullName.StartsWith("DeveloperGames", StringComparison.InvariantCultureIgnoreCase)));
            return ts;
        }

        public static void RegisterComponents()
        {
            container = new UnityContainer();
            container.RegisterTypes(GetTypes(),
                WithMappings.FromMatchingInterface,
                WithName.Default);

            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }
    }
}