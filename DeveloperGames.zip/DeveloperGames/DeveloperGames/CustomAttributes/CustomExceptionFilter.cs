﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace DeveloperGames.CustomAttributes
{
    public class CustomExceptionFilter : FilterAttribute,IExceptionFilter
    {
        public void OnException(ExceptionContext filterContext)
        {

            string filepath = HttpContext.Current.Server.MapPath("~/logs/") ;
            string fileName = "Logs" + DateTime.Now.Date.ToString("dd/mm/yyyy") + "_" + DateTime.Now.Millisecond + ".txt";
            filepath = filepath + fileName;
            Exception ex = filterContext.Exception;

            if (!Directory.Exists(filepath))
            {
                Directory.CreateDirectory(filepath);

            }
            if (!File.Exists(filepath))
            {
                File.Create(filepath).Dispose();

            }

            using (StreamWriter writer = new StreamWriter(filepath, true))
            {
                writer.WriteLine("-----------------------------------------------------------------------------");
                writer.WriteLine("Date : " + DateTime.Now.ToString());
                writer.WriteLine();

                while (ex != null)
                {
                    writer.WriteLine(ex.GetType().FullName);
                    writer.WriteLine("Message : " + ex.Message);
                    writer.WriteLine("StackTrace : " + ex.StackTrace);

                    ex = ex.InnerException;
                }
            }

            filterContext.ExceptionHandled = true;

            filterContext.Result = new RedirectToRouteResult(
               new RouteValueDictionary{{ "controller", "Account" },{ "action", "Error" } });
        }
    }
}