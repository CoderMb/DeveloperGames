﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace DeveloperGames.CustomAttributes
{
    public class BaseAuthorizeAttribute : AuthorizeAttribute
    {
        public string Role { get; set; }

        public BaseAuthorizeAttribute(string role="")
        {
            this.Role = role;
        }
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {

            return !(httpContext.Session.Keys.Count == 0) &&  httpContext.User.Identity.IsAuthenticated;
        }

        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            base.OnAuthorization(filterContext);

            if (this.AuthorizeCore(filterContext.HttpContext))
            {
                //check is admin or not
                var claims = (System.Security.Claims.ClaimsIdentity)filterContext.HttpContext.User.Identity;
                var role = claims.Claims.FirstOrDefault(s => s.Type.Contains("Role"))?.Value;

                if(!String.IsNullOrEmpty(this.Role) &&  !this.Role.Equals(role,StringComparison.InvariantCultureIgnoreCase))
                {
                    //unAuthorized
                    RouteValueDictionary route = new RouteValueDictionary();
                    route.Add("controller", "Account");
                    route.Add("action", "Unauthorized");
                    filterContext.Result = new RedirectToRouteResult("Default", route);
                }
                
                //this.HandleUnauthorizedRequest(filterContext);
            }

        }

        //public override void OnAuthorization(AuthorizationContext filterContext)
        //{
        //    base.OnAuthorization(filterContext);
        //    if (filterContext.Result == null)
        //    {
        //        if (filterContext.HttpContext.Session.Keys.Count == 0 || !filterContext.HttpContext.User.Identity.IsAuthenticated)
        //        {
        //            var claims = (System.Security.Claims.ClaimsIdentity)filterContext.HttpContext.User.Identity;
        //            var
        //        }
        //    }
        //}

        //protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        //{
        //    //filterContext.Result = new HttpUnauthorizedResult(); // Try this but i'm not sure

        //    filterContext.Result = new RedirectResult("~/Account/Unauthorized");
        //}

    }
}