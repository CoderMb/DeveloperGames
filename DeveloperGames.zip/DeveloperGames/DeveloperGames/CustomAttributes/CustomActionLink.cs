﻿using DeveloperGames.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace DeveloperGames.CustomAttributes
{
    public static class CustomActionLink
    {
        public static HtmlString EncodedActionLink(this HtmlHelper htmlHelper,string linkText,string actionName,string controllerName,object routeValues,object htmlAttributes)
        {
            string queryString = string.Empty;
            string htmlAttributeString = string.Empty;
            if(routeValues!=null)
            {

                RouteValueDictionary d = new RouteValueDictionary(routeValues);
                for(int i=0;i<d.Keys.Count; i++)
                {
                    if(i>0)
                    {
                        queryString += "&";
                    }
                    queryString += d.Keys.ElementAt(i) + "=" + d.Values.ElementAt(i);
                }
            }

            if(htmlAttributes != null)
            {
                RouteValueDictionary d = new RouteValueDictionary(htmlAttributes);
                for(int i=0;i< d.Keys.Count;i++)
                {
                    htmlAttributeString += " " + d.Keys.ElementAt(i) + "='" + d.Values.ElementAt(i) + "'";
                }

            }

            StringBuilder ancor = new StringBuilder();
            ancor.Append("<a ");
            if(!String.IsNullOrEmpty(htmlAttributeString))
            {
                ancor.Append(htmlAttributeString);
            }
            ancor.Append(" href='");
            if(!String.IsNullOrEmpty(controllerName))
            {
                ancor.Append("/"+controllerName);
            }
            if(!String.IsNullOrEmpty(actionName))
            {
                ancor.Append("/"+actionName);
            }
            if(!String.IsNullOrEmpty(queryString))
            {
                ancor.Append("?q="+Hash.EncryptParameters(queryString));
            }
            ancor.Append("'");
            ancor.Append(">");
            ancor.Append(linkText);
            ancor.Append("</a>");
            return new HtmlString(ancor.ToString());
        }
    }
}