﻿using DeveloperGames.Core.Interfaces;
using DeveloperGames.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DeveloperGames.Core.ViewModels;
using DeveloperGames.Core.Models;
using DeveloperGames.Core.Enums;
using System.Web.Providers.Entities;
using DeveloperGames.CustomAttributes;
using System.Text.RegularExpressions;

namespace DeveloperGames.Controllers
{
    [BaseAuthorize]
    public class UserController : Controller
    {
        private readonly IUserManager userManager;
        private readonly IAdminManager adminManager;
        private const int characterSettingId = 1;

        public UserController(IUserManager userManager,IAdminManager adminManager)
        {
          
            this.userManager = userManager;
            this.adminManager = adminManager;
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult User(string id, string user)
        {
            var userId = Convert.ToInt32(id) == 0 ? Convert.ToInt32(Session["UserId"]) : Convert.ToInt32(id);
            UserViewModel userViewModel = new UserViewModel();
            TempData["UserName"] = user;
            TempData["UserId"] = userId;
            TempData["ClassesVisibility"] = "HIDE";
            userViewModel.Classes = getClasses();
            userViewModel.Characters = GetCharacters(userId, 0);
            userViewModel.Character = new CharacterEntity { UserId = userId , UserName = user, Gender = "Male" };
            userViewModel.IsEdit = false;
            return View(userViewModel); 
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult EditCharacter(string characterId, string userId, string userName)
        {
            int cId = Convert.ToInt32(characterId);
            int uId = Convert.ToInt32(userId) == 0 ? Convert.ToInt32(Session["UserId"]) : Convert.ToInt32(userId);
            TempData["ClassesVisibility"] = "SHOW";
            //TempData["UserName"] = userName;
            UserViewModel userViewModel = new UserViewModel();
            userViewModel.Classes = getClasses();
            userViewModel.Characters = GetCharacters(uId, 0);
            userViewModel.Character = GetCharacters(uId, cId).FirstOrDefault();
            userViewModel.IsEdit = true;
            return View("User", userViewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateCharacter(UserViewModel userViewModel)
        {
            if (ModelState.IsValid && ValidateRequest(userViewModel))
            {
                int userID = userViewModel.Character.UserId == 0 ? Convert.ToInt32(Session["UserId"]) : userViewModel.Character.UserId;
                string userName = userViewModel.Character.UserName;
                userViewModel.Character.UserId = userID;
                userViewModel.Characters = GetCharacters(userID,0);
                userViewModel.Classes = getClasses();
                var count = userViewModel.Characters.Count;
                List<GlobalSettings> globalSettings = adminManager.GetGlobalSettings();
                var charSetting = globalSettings.Where(s => s.GlobalSettingKeyId == characterSettingId).FirstOrDefault();
                if(userViewModel.IsEdit && count <= charSetting.GlobalSettingKeyValue)
                {
                    int res = userManager.SetCharacter(userViewModel.Character);
                    if (res == -1)
                    {
                        TempData["MessageClass"] = "alert-show alert-danger";
                        TempData["Message"] = "Character Already Exists";
                        return View("user", userViewModel);
                    }
                }
                else if(count < charSetting.GlobalSettingKeyValue)
                {
                    int res = userManager.SetCharacter(userViewModel.Character);
                    if (res == -1)
                    {
                        TempData["MessageClass"] = "alert-show alert-danger";
                        TempData["Message"] = "Character Already Exists";
                        return View("user", userViewModel);
                    }
                }
                else
                {
                    TempData["MessageClass"] = "alert-show alert-danger";
                    TempData["Message"] = "Character Limit Has Reached Already";
                    return View("user", userViewModel);
                }
                
                
                return RedirectToAction("User", new { id = userID, user = userName });
            }
            else
            {
                userViewModel.Characters = GetCharacters(userViewModel.Character.UserId == 0 ? Convert.ToInt32(Session["UserId"]) : userViewModel.Character.UserId, 0);
                userViewModel.Classes = getClasses();
                return View("user",userViewModel);
            }
        } 

        public void clearFields(UserViewModel userViewModel)
        {
            userViewModel.Character = new CharacterEntity();
        }

        private List<CharacterEntity> GetCharacters(int userId,int CharId)
        {
            return userManager.GetCharacters(userId, CharId);
        }

        private List<ClassEntity> getClasses()
        {
            return adminManager.GetAllClasses();
        }

        private bool ValidateRequest(UserViewModel userViewModel)
        {
            if(userViewModel.Character.ClassId == 0)
            {
                TempData["MessageClass"] = "alert-show alert-danger";
                TempData["Message"] = "Class not selected";
                return false;
            }
            else if (userViewModel.Character == null)
            {
                TempData["MessageClass"] = "alert-show alert-danger";
                TempData["Message"] = "Character Invalid";
                return false;

            }
            else if(userViewModel.Character.CharacterName.Length <= 0)
            {
                TempData["MessageClass"] = "alert-show alert-danger";
                TempData["Message"] = "Character Name Required";
                return false;
                
            }
            else if(userViewModel.Character.CharacterName.Length > 0)
            {
                TempData["MessageClass"] = "alert-show alert-danger";
                TempData["Message"] = "Character Name invalid";
                return Regex.IsMatch(userViewModel.Character.CharacterName, @"^[a-zA-Z0-9]+$");
            }
            else
            {
                return true;
            }
        }
    }
}