﻿using DeveloperGames.Core.Interfaces;
using DeveloperGames.Core.ViewModels;
using DeveloperGames.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DeveloperGames.CustomAttributes;
using DeveloperGames.Utilities;

namespace DeveloperGames.Controllers
{
    [BaseAuthorize("Admin")]
    public class AdminController : Controller
    {
        private IAdminManager adminManager;
        private const int characterSettingId = 1;
        public AdminController(IAdminManager adminManager)
        {
            this.adminManager = adminManager;
        }
       
        [HttpGet]
        public ActionResult Dashboard()
        {
            List<GlobalSettings> globalSettings = adminManager.GetGlobalSettings();
            var charSetting = globalSettings.Where(s => s.GlobalSettingKeyId == characterSettingId).FirstOrDefault();
            Setting setting = new Setting
            {
                KeyId = charSetting.GlobalSettingKeyId,
                KeyName = charSetting.GlobalSettingKeyName,
                KeyValue = charSetting.GlobalSettingKeyValue
            };
            TempData["CharacterCapacity"] = charSetting.GlobalSettingKeyValue;

            UserViewModel userViewModel = new UserViewModel() {
                Classes = adminManager.GetAllClasses(),
                Users = adminManager.GetUsers()?.Select(s=> {
                   s.Email= Hash.DecryptParameters(s.Email);
                    return s; }).ToList(),
                CharacterSetting = setting
            };

            return View(userViewModel);
        }
        public PartialViewResult ClassList()
        {
            return PartialView();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SaveClass(FormCollection fc)
        {
            ClassEntity classList = new ClassEntity {
                ClassName = fc["className"],
                ClassDescription = fc["classDescription"],
                ClassImageURL = fc["ClassImageURL"],
                GlobalSettingsKeyId = 1
            };
            adminManager.SetClass(classList);
            return RedirectToAction("Dashboard");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SaveCharacterCapacity(FormCollection fc)
        {
            var strCapacity = fc["characterCapacity"];
            int capacity;
            bool isValueAllowed = Int32.TryParse(strCapacity, out capacity);

            if (isValueAllowed && capacity > Convert.ToInt32(TempData["CharacterCapacity"]))
            {
                adminManager.SetCharacterSetting(characterSettingId, capacity);
            }

            return RedirectToAction("Dashboard");
        }

    }
}