﻿using CaptchaMvc.HtmlHelpers;
using DeveloperGames.Core.Interfaces;
using DeveloperGames.Core.Models;
using DeveloperGames.Core.ViewModels;
using DeveloperGames.CustomAttributes;
using DeveloperGames.Utilities;
using Microsoft.Owin.Security;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Claims;
using System.Web;
using System.Web.Mvc;

namespace DeveloperGames.Controllers
{

    public class AccountController : Controller
    {
        private IUserManager userManager;
        public AccountController(IUserManager userManager)
        {
            this.userManager = userManager;
        }
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult Login(LoginViewModel loginModel)
        {
            if (ModelState.IsValid)
            {
                var user = userManager.getUserInfobyUserName(loginModel.UserName);
                if (user != null) //check for user details
                {

                    var password = Hash.generteHashPassword(loginModel.Password);
                    if (password != user.Password)
                    {
                        //update attempts
                        var loginAttempts = this.userManager.SetLoginAttemptsByUserId(user.UserId, reset: false);
                        if (loginAttempts > Convert.ToInt32(ConfigurationManager.AppSettings["MaxLoginAttempts"]))
                        {
                            TempData["MessageClass"] = "alert-show alert-danger";
                            TempData["Message"] = "Maximum Login attempts reached.Please contact admin to unlock your account";

                        }

                        TempData["MessageClass"] = "alert-show alert-danger";
                        TempData["Message"] = "Invalid Password";
                    }
                    else
                    {
                        this.userManager.SetLoginAttemptsByUserId(user.UserId, reset: true);
                        Session["UserId"] = user.UserId;
                        Session["Role"] = user.IsAdmin ? "Admin" : "User";
                        var claims = new[] {new Claim(ClaimTypes.Name, user.UserName),
                            new Claim(ClaimTypes.NameIdentifier, user.Email),  //in order for the antifogery claim to be unique
                        new Claim("Role",user.IsAdmin?"Admin":"User")};
                        var identity = new ClaimsIdentity(claims, "ApplicationCookie");
                        var context = HttpContext.GetOwinContext();
                        var authManager = context.Authentication;

                        //passing identity for OWIN middleware sign in
                        authManager.SignIn(new AuthenticationProperties { IsPersistent = true }, identity);

                        return user.IsAdmin ? RedirectToAction("Dashboard", "Admin") : RedirectToAction("User", "User");

                    }
                }
                else
                {
                    //invalid username
                    TempData["MessageClass"] = "alert-show alert-danger";
                    TempData["Message"] = "Invalid Username";
                }
            }
            return View(loginModel);
        }

        [HttpGet]
        [AllowAnonymous]
        public ActionResult Register()
        {
            return View();
        }

        [BaseAuthorize]
        public ActionResult RedirectByRole()
        {
            return "Admin".Equals(Convert.ToString(Session["Role"]),StringComparison.InvariantCultureIgnoreCase) ? RedirectToAction("Dashboard", "Admin") : RedirectToAction("User", "User");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [AllowAnonymous]
        public ActionResult Register(RegisterViewModel registerModel)
        {
            if (this.IsCaptchaValid("Captcha is not valid"))
            {
                if (ModelState.IsValid)
                {
                    User user = new User()
                    {
                        UserId = 0,
                        UserName = registerModel.UserName,
                        Email = Hash.EncryptParameters(registerModel.Email),
                        Password = Hash.generteHashPassword(registerModel.Password)
                    };

                    var result = this.userManager.setUserInfo(user);

                    if (result > 0)
                    {
                        TempData["MessageClass"] = "alert-show alert-success";
                        TempData["Message"] = "User registered successfully";
                        return RedirectToAction("Login", "Account");
                    }
                    else if (result == -1)
                    {
                        TempData["MessageClass"] = "alert-show alert-danger";
                        TempData["Message"] = "Username/Email already exists";
                    }
                    else if (result == -2)
                    {
                        TempData["MessageClass"] = "alert-show alert-success";
                        TempData["Message"] = "An error occured while saving. Please contact admin";
                    }
                }
            }
            else
            {
                TempData["MessageClass"] = "alert-show alert-danger";
                TempData["Message"] = "Captcha is not valid";
            }
            return View(registerModel);
        }


        [HttpGet]
        [BaseAuthorize]
        public ActionResult ChangePassword()
        {
            ChangePasswordViewModel changePassword = new ChangePasswordViewModel();
            return View(changePassword);

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [BaseAuthorize]
        public ActionResult ChangePassword(ChangePasswordViewModel changePassword)
        {
            if (ModelState.IsValid)
            {
             var result = this.userManager.SetPassword(Convert.ToInt32(Session["UserId"]), Hash.generteHashPassword(changePassword.NewPassword));
                if (result > 0)
                {
                    TempData["MessageClass"] = "alert-show alert-success";
                    TempData["Message"] = "New password updated";
                    return RedirectToAction("RedirectByRole");
                }
                else
                {
                    TempData["MessageClass"] = "alert-show alert-danger";
                    TempData["Message"] = "An error occured while saving. Please contact admin";
                }
            }
            return View(changePassword);

        }


        public ActionResult Unauthorized()
        {

            return View();
        }


        [BaseAuthorize]
        public ActionResult LogOut()
        {
            var authorizationManager = Request.GetOwinContext().Authentication;
            authorizationManager.SignOut("ApplicationCookie");
            return RedirectToAction("Login");
        }
    }
}