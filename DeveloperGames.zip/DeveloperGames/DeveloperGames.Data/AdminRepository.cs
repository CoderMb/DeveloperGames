﻿using Dapper;
using DeveloperGames.Core.Interfaces.Repositories;
using DeveloperGames.Core.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace DeveloperGames.Data
{
    public class AdminRepository : IAdminRepository
    {
        private string connectionString = ConfigurationManager.ConnectionStrings["DGConnectionString"].ConnectionString;
        public List<ClassEntity> GetAllClasses()
        {
            using (var con = new SqlConnection(connectionString))
            {
                return con.Query<ClassEntity>("cpGetAllClasses", commandType: System.Data.CommandType.StoredProcedure).ToList();
            }
        }

        public int SetClass(ClassEntity classList)
        {
            var dynamicParameter = new DynamicParameters();
            dynamicParameter.Add("@ClassName", classList.ClassName);
            dynamicParameter.Add("@ClassDescription", classList.ClassDescription);
            dynamicParameter.Add("@ClassImageURL", classList.ClassImageURL);
            dynamicParameter.Add("@GlobalSettingKeyId", classList.GlobalSettingsKeyId);
            dynamicParameter.Add("@ExecuteStatus", dbType: System.Data.DbType.Int32, direction: System.Data.ParameterDirection.Output);


            using (var con = new SqlConnection(connectionString))
            {
                con.Execute("cpSetClass", dynamicParameter, commandType: System.Data.CommandType.StoredProcedure);
                return dynamicParameter.Get<int>("@ExecuteStatus");

            }
        }

        public List<GlobalSettings> GetGlobalSettings()
        {
            using (var con = new SqlConnection(connectionString))
            {
                return con.Query<GlobalSettings>("cpGetGlobalSettings", commandType: System.Data.CommandType.StoredProcedure).ToList();
            }
        }

        public int SetCharacterSetting(int id, int capacity)
        {
            var dynamicParameter = new DynamicParameters();
            dynamicParameter.Add("@GlobalSettingKeyId", id);
            dynamicParameter.Add("@@GlobalSettingKeyValue", capacity);
            dynamicParameter.Add("@ExecuteStatus", dbType: System.Data.DbType.Int32, direction: System.Data.ParameterDirection.Output);


            using (var con = new SqlConnection(connectionString))
            {
                con.Execute("cpSetGlobalSetting", dynamicParameter, commandType: System.Data.CommandType.StoredProcedure);
                return dynamicParameter.Get<int>("@ExecuteStatus");

            }
        }
    }
}
