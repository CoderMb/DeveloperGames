﻿using DeveloperGames.Core.Interfaces.Repositories;
using DeveloperGames.Core.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace DeveloperGames.Data
{
    public class UserRepository : IUserRepository
    {
        //will move it to baseClass later
        private string connectionString = ConfigurationManager.ConnectionStrings["DGConnectionString"].ConnectionString;


        public List<User> GetUsers()
        {
            using (var con = new SqlConnection(connectionString))
            {
                return con.Query<User>("cpGetUser", commandType: System.Data.CommandType.StoredProcedure).ToList();
            }
        }


        public User GetUserById(int userId)
        {
            using (var con = new SqlConnection(connectionString))
            {
                return con.QueryFirstOrDefault<User>("cpGetUser", new {@UserId = userId }, commandType: System.Data.CommandType.StoredProcedure);
            }
        }
        public User GetUserByUserName(string username)
        {
            using (var con = new SqlConnection(connectionString))
            {
                return con.QueryFirstOrDefault<User>("cpGetUserByUsername", new { @Username = username }, commandType: System.Data.CommandType.StoredProcedure);
            }
        }
        public int SetPassword(int userId,string password)
        {
            using (var con = new SqlConnection(connectionString))
            {
                return con.Execute("cpSetPassword", new { @Password = password, @UserId=userId }, commandType: System.Data.CommandType.StoredProcedure);
            }
        }

        public int SetLoginAttemptsByUserId(int userId,bool reset)
        {
            using (var con = new SqlConnection(connectionString))
            {
                return con.QueryFirstOrDefault<int>("cpSetLoginAttempts", new { @UserId = userId, @IsReset = reset }, commandType: System.Data.CommandType.StoredProcedure);
            }
        }

        public int SetUser(User user)
        {
            var dynamicParameter = new DynamicParameters();
            dynamicParameter.Add("@UserId", user.UserId);
            dynamicParameter.Add("@UserName", user.UserName);
            dynamicParameter.Add("@Password", user.Password);
            dynamicParameter.Add("@EmailId", user.Email);
            dynamicParameter.Add("@LoginUserId", 1);
            dynamicParameter.Add("@ExecuteStatus",dbType:System.Data.DbType.Int32,direction:System.Data.ParameterDirection.Output);


            using (var con = new SqlConnection(connectionString))
            {
                con.Execute("cpSetUser", dynamicParameter, commandType: System.Data.CommandType.StoredProcedure);
                return dynamicParameter.Get<int>("@ExecuteStatus");

            }
        }

        public IEnumerable<CharacterEntity> GetCharacters(int userId, int characterId)
        {
            using (var con = new SqlConnection(connectionString))
            {
                return con.Query<CharacterEntity>("cpGetCharacters", new { @UserId = userId , @CharacterId = characterId}, commandType: System.Data.CommandType.StoredProcedure);
            }
        }

        public int SetCharacter(CharacterEntity charc)
        {
            var dynamicParameter = new DynamicParameters();
            dynamicParameter.Add("@CharacterId", charc.CharacterId);
            dynamicParameter.Add("@CharacterName", charc.CharacterName);
            dynamicParameter.Add("@ClassId", Convert.ToInt32(charc.ClassId));
            dynamicParameter.Add("@UserId", charc.UserId);
            dynamicParameter.Add("@Gender", charc.Gender);
            dynamicParameter.Add("@ImageUrl", charc.CharacterImage);
            dynamicParameter.Add("@ExecuteStatus", dbType: System.Data.DbType.Int32, direction: System.Data.ParameterDirection.Output);


            using (var con = new SqlConnection(connectionString))
            {
                con.Execute("cpSetCharacter", dynamicParameter, commandType: System.Data.CommandType.StoredProcedure);
                return dynamicParameter.Get<int>("@ExecuteStatus");
            }
        }

        
    }
}
